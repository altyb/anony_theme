<h1 align="center">Anony_style </h1>
<p align="center">
      New advanced terminal for Termux users with simple steps
</p>

## About Anony_theme :

Anony_style is a bash based script which modifies and changes your terminal from boring to awesome in just oneclick without any issue and without root. This tool works on both rooted Android device and Non-rooted Android device.


### Anony_style is available for

* Termux

### Installation and usage guide
```
```
$ apt-get update -y
```
```
$ apt-get upgrade -y
```
```
$ pkg install git -y
```
```
$ git clone https://github.com/kamix4/Hacker
```
```
$ cd Anony_style
```
```
$ bash Anony_style.sh
```
```
* Now make sue that you internet connection is on and after that the installation starts automatically
```
```
* After the installation succesfully completes you will see a THANKS text on screen after that a new text appears 
```
```
* EXIT FROM TERMUX AFTER 5 SECONDS AND RE-OPEN IT after seeing this just exit from termux and re open it 
```
```
Now you can see a new loading screen of termux and you can feel real hacking terminal Sound+New interface with banner. 
```
```
Note:- Don't delete any of the audio files from your sdcard/internal storage or else you cannot feel the terminal startup sound
```
```
To revert/to get back into normal termux mode use this commands
```
```
cd Anony_style
```
ls
```
bash rvt.sh
```
```

### Chekout our webite
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
